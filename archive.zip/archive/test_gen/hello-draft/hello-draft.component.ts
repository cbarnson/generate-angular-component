import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-hello-draft-component",
  templateUrl: "./hello-draft.component.html"
})
export class HelloDraftComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {}
}

